

<html>

<title> IPTABLES 2S INTERVAL</title>

<head> 
<style>

#demo{
	white-space: pre;
	font-family: monospace;

}

</style></head>


<body>

<p id="demo"></p>

<script>

var xhttp = new XMLHttpRequest();
xhttp.onload = result;


xhttp.open("POST", "iptables-list");
xhttp.send();


setInterval(function(){
xhttp.open("POST", "iptables-list")
xhttp.send();
}, 1000)


function result(){
document.getElementById("demo").textContent = this.response;
}

</script>



</body>


</html>

