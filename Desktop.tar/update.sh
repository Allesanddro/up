#!/bin/bash 
iptables -nvL > /var/www/html/ip/iptables-list
